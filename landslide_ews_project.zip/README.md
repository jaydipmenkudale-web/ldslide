# Landslide Early Warning System — SIH26001

AI-based early warning and landslide risk monitoring for the North Eastern Region.
Software track, Ministry of Development of North Eastern Region.

This is a working full-stack scaffold: a FastAPI backend with a swappable risk-scoring
model, and a React frontend with a resident-facing view and an officer dashboard.
Both have been run and tested end to end — this isn't just a UI mockup.

## Structure

```
backend/    FastAPI + SQLAlchemy + SQLite. Risk scoring, alerts, ground reports.
frontend/   React + Vite. Resident app view and officer dashboard, polling the API.
```

## Running it

**Backend**
```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```
API docs: http://localhost:8000/docs
Seed data (4 NER zones) loads automatically on first run.

**Frontend**
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173. Vite proxies `/api/*` to the backend on port 8000
(see `frontend/vite.config.js`) — no CORS setup needed for local dev.

## What's real vs. what's a stub

| Piece | Status |
|---|---|
| Zone risk scoring | Real, working weighted formula in `risk_model.py` — swap for a trained ML model without touching the API (see comments in that file) |
| Ground report → risk feedback loop | Real — submitting a report recomputes the zone's score |
| Alert generation | Real — alerts are created and stored when a zone crosses "high"/"critical" |
| SMS / push delivery | Stubbed — logs to console. Wire up Twilio / Firebase in `alerts.py` before a live demo |
| Rainfall / DEM / soil data | Seeded with representative values for 4 NER zones. Replace `seed.py` with live pulls from IMD, Bhuvan, and soil sensors for production |
| Database | SQLite for local dev. Swap the URL in `database.py` for Postgres + PostGIS when you need real geospatial queries |

## Next steps for the hackathon

1. Replace the weighted-formula risk model with a trained classifier (see the
   docstring in `backend/app/risk_model.py` for the swap-in point).
2. Wire up Twilio for real SMS alerts (`backend/app/alerts.py`).
3. Add a real map (Leaflet/Mapbox) to the officer dashboard in place of the
   zone list — `frontend/src/App.jsx` is where that would go.
4. Pull live rainfall from the IMD API and terrain data from Bhuvan/ISRO to
   replace the seeded zone values.
