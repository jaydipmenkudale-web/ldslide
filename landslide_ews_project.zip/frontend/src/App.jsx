import React, { useEffect, useState } from "react";
import { api } from "./api";

const C = {
  ink: "#1C1F1B",
  slate: "#2B3630",
  slateLight: "#3E4B42",
  paper: "#F3F1E9",
  moss: "#5B7A5A",
  mossDark: "#3D5A3D",
  amber: "#C68A2E",
  rust: "#B4502B",
  rustDark: "#7A3419",
  line: "#D9D5C7",
};

const riskColor = (r) =>
  r === "critical" ? C.rustDark : r === "high" ? C.rust : r === "moderate" ? C.amber : C.moss;

function RiskPill({ risk }) {
  return (
    <span
      style={{
        color: riskColor(risk),
        border: `1px solid ${riskColor(risk)}`,
        borderRadius: 4,
        padding: "2px 8px",
        fontSize: 12,
        fontWeight: 500,
        textTransform: "capitalize",
      }}
    >
      {risk}
    </span>
  );
}

function useZones(pollMs = 15000) {
  const [zones, setZones] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const data = await api.listZones();
        if (!cancelled) setZones(data);
      } catch (e) {
        if (!cancelled) setError(e.message);
      }
    }
    load();
    const id = setInterval(load, pollMs);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [pollMs]);

  return { zones, error };
}

function ReportForm({ zoneId, onSubmitted }) {
  const [description, setDescription] = useState("");
  const [severity, setSeverity] = useState("minor");
  const [status, setStatus] = useState(null);

  const submit = async (e) => {
    e.preventDefault();
    if (!description.trim()) {
      setStatus({ ok: false, msg: "Describe what you saw before submitting." });
      return;
    }
    try {
      await api.submitReport(zoneId, { description, severity });
      setDescription("");
      setStatus({ ok: true, msg: "Report submitted. Thank you." });
      onSubmitted?.();
    } catch (err) {
      setStatus({ ok: false, msg: err.message });
    }
  };

  return (
    <form onSubmit={submit} style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      <textarea
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        placeholder="What did you notice? e.g. a new crack, water seepage, unusual sound"
        rows={3}
        style={{ padding: 10, borderRadius: 8, border: `1px solid ${C.line}`, fontSize: 13, resize: "vertical" }}
      />
      <select
        value={severity}
        onChange={(e) => setSeverity(e.target.value)}
        style={{ padding: 8, borderRadius: 8, border: `1px solid ${C.line}`, fontSize: 13 }}
      >
        <option value="minor">Minor — small change, no immediate danger</option>
        <option value="moderate">Moderate — worth checking soon</option>
        <option value="severe">Severe — looks urgent</option>
      </select>
      <button
        type="submit"
        style={{ padding: "10px 14px", borderRadius: 8, border: "none", background: C.mossDark, color: "#fff", fontSize: 13, cursor: "pointer" }}
      >
        Submit report
      </button>
      {status && (
        <div style={{ fontSize: 12, color: status.ok ? C.mossDark : C.rustDark }}>{status.msg}</div>
      )}
    </form>
  );
}

function ResidentApp() {
  const { zones, error } = useZones();
  const [refreshKey, setRefreshKey] = useState(0);
  const primary = zones[0];

  if (error) return <div style={{ padding: 20, color: C.rustDark }}>Could not reach the API: {error}</div>;
  if (!primary) return <div style={{ padding: 20, color: C.slateLight }}>Loading zones…</div>;

  return (
    <div style={{ width: 360, background: C.paper, borderRadius: 20, overflow: "hidden", fontFamily: "system-ui, sans-serif" }}>
      <div style={{ background: riskColor(primary.risk_level), color: "#fff", padding: "18px 20px" }}>
        <div style={{ fontWeight: 500, fontSize: 15, textTransform: "capitalize" }}>{primary.risk_level} risk near you</div>
        <p style={{ margin: "6px 0 0", fontSize: 13, opacity: 0.9, lineHeight: 1.5 }}>
          {primary.name}, {primary.village}. Risk score {primary.risk_score}/100.
        </p>
      </div>

      <div style={{ padding: 20 }}>
        <h3 style={{ fontSize: 14, fontWeight: 500, color: C.ink, marginBottom: 8 }}>All zones</h3>
        {zones.map((z) => (
          <div
            key={z.id}
            style={{
              display: "flex", justifyContent: "space-between", alignItems: "center",
              padding: "10px 0", borderTop: `1px solid ${C.line}`,
            }}
          >
            <div>
              <div style={{ fontSize: 13, color: C.ink }}>{z.name}</div>
              <div style={{ fontSize: 11, color: C.slateLight }}>{z.village}</div>
            </div>
            <RiskPill risk={z.risk_level} />
          </div>
        ))}

        <h3 style={{ fontSize: 14, fontWeight: 500, color: C.ink, marginTop: 20, marginBottom: 8 }}>
          Report a ground sign near {primary.name}
        </h3>
        <ReportForm zoneId={primary.id} onSubmitted={() => setRefreshKey((k) => k + 1)} key={refreshKey} />
      </div>
    </div>
  );
}

function OfficerDashboard() {
  const { zones, error } = useZones();
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const data = await api.listAlerts();
        if (!cancelled) setAlerts(data);
      } catch {
        /* alerts are supplementary; ignore transient errors here */
      }
    }
    load();
    const id = setInterval(load, 15000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, []);

  if (error) return <div style={{ padding: 20, color: C.rustDark }}>Could not reach the API: {error}</div>;

  return (
    <div style={{ width: 680, background: C.slate, borderRadius: 20, overflow: "hidden", fontFamily: "system-ui, sans-serif", color: C.paper }}>
      <div style={{ padding: "18px 24px", borderBottom: `1px solid ${C.slateLight}`, display: "flex", justifyContent: "space-between" }}>
        <span style={{ fontWeight: 500, fontSize: 15 }}>NER landslide monitoring — District desk</span>
        <span style={{ fontSize: 12, color: "#B7C2B8" }}>{alerts.length} alerts logged</span>
      </div>

      <div style={{ padding: 24 }}>
        <div style={{ fontSize: 12, color: "#B7C2B8", marginBottom: 8 }}>Zones by risk</div>
        {zones.map((z) => (
          <div
            key={z.id}
            style={{
              display: "flex", justifyContent: "space-between", alignItems: "center",
              padding: "10px 12px", background: C.slateLight, borderRadius: 10, marginBottom: 8,
            }}
          >
            <div>
              <div style={{ fontSize: 13 }}>{z.name}</div>
              <div style={{ fontSize: 11, color: "#B7C2B8" }}>{z.village}, {z.district}</div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ fontSize: 12, color: "#B7C2B8" }}>{z.risk_score}/100</span>
              <RiskPill risk={z.risk_level} />
            </div>
          </div>
        ))}

        <div style={{ fontSize: 12, color: "#B7C2B8", margin: "20px 0 8px" }}>Recent alerts</div>
        <div style={{ maxHeight: 200, overflowY: "auto", display: "flex", flexDirection: "column", gap: 6 }}>
          {alerts.slice(0, 8).map((a) => (
            <div key={a.id} style={{ fontSize: 12, padding: "8px 12px", background: C.slateLight, borderRadius: 8 }}>
              <span style={{ color: riskColor(a.risk_level), fontWeight: 500, textTransform: "capitalize" }}>{a.risk_level}</span>
              {" — "}
              {a.message}
            </div>
          ))}
          {alerts.length === 0 && <div style={{ fontSize: 12, color: "#B7C2B8" }}>No alerts yet.</div>}
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [view, setView] = useState("resident");
  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", padding: 32, background: C.paper, gap: 20 }}>
      <div style={{ display: "flex", gap: 8 }}>
        <button
          onClick={() => setView("resident")}
          style={{
            padding: "8px 16px", borderRadius: 8, border: `1px solid ${C.line}`, cursor: "pointer",
            background: view === "resident" ? C.mossDark : "#fff",
            color: view === "resident" ? "#fff" : C.ink, fontSize: 13,
          }}
        >
          Resident app
        </button>
        <button
          onClick={() => setView("officer")}
          style={{
            padding: "8px 16px", borderRadius: 8, border: `1px solid ${C.line}`, cursor: "pointer",
            background: view === "officer" ? C.mossDark : "#fff",
            color: view === "officer" ? "#fff" : C.ink, fontSize: 13,
          }}
        >
          Officer dashboard
        </button>
      </div>
      {view === "resident" ? <ResidentApp /> : <OfficerDashboard />}
    </div>
  );
}
