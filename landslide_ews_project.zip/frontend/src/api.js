// Thin wrapper around the FastAPI backend. In dev, Vite proxies /api -> localhost:8000
// (see vite.config.js). In production, set this to your deployed API's base URL.
const BASE = "/api";

async function request(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`${res.status} ${res.statusText}: ${body}`);
  }
  return res.json();
}

export const api = {
  listZones: () => request("/zones"),
  getZone: (id) => request(`/zones/${id}`),
  refreshZone: (id, inputs) =>
    request(`/zones/${id}/refresh`, { method: "POST", body: JSON.stringify(inputs) }),
  submitReport: (id, report) =>
    request(`/zones/${id}/reports`, { method: "POST", body: JSON.stringify(report) }),
  listAlerts: () => request("/alerts"),
};
