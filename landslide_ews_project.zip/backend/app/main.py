"""
Landslide Early Warning System — backend API
SIH26001 — AI-based early warning and landslide risk monitoring for NER

Run locally:
    cd backend
    pip install -r requirements.txt
    uvicorn app.main:app --reload --port 8000

Docs available at http://localhost:8000/docs
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from app.database import Base, engine, get_session
from app import models, schemas
from app.risk_model import compute_risk_score
from app.alerts import dispatch_alert_if_needed
from app.seed import seed_if_empty

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Landslide Early Warning System",
    description="API for zone risk monitoring, alerts, and crowdsourced ground reports.",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten this to your frontend origin before deploying
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    with get_session() as session:
        seed_if_empty(session)


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/zones", response_model=list[schemas.ZoneOut])
def list_zones():
    """All monitored zones with their current risk score, sorted highest risk first."""
    with get_session() as session:
        zones = session.query(models.Zone).order_by(models.Zone.risk_score.desc()).all()
        return zones


@app.get("/zones/{zone_id}", response_model=schemas.ZoneDetailOut)
def get_zone(zone_id: int):
    with get_session() as session:
        zone = session.query(models.Zone).filter(models.Zone.id == zone_id).first()
        if not zone:
            raise HTTPException(status_code=404, detail="Zone not found")
        reports = (
            session.query(models.GroundReport)
            .filter(models.GroundReport.zone_id == zone_id)
            .order_by(models.GroundReport.created_at.desc())
            .limit(20)
            .all()
        )
        return schemas.ZoneDetailOut(
            id=zone.id, name=zone.name, village=zone.village, district=zone.district,
            risk_score=zone.risk_score, risk_level=zone.risk_level,
            rainfall_mm_24h=zone.rainfall_mm_24h, slope_degrees=zone.slope_degrees,
            soil_moisture_pct=zone.soil_moisture_pct,
            recent_reports=[schemas.GroundReportOut.model_validate(r) for r in reports],
        )


@app.post("/zones/{zone_id}/refresh", response_model=schemas.ZoneOut)
def refresh_zone_risk(zone_id: int, inputs: schemas.RiskInputs):
    """
    Recompute a zone's risk score from fresh sensor/weather inputs.
    In production this endpoint would be called by a scheduled ingestion job
    pulling from IMD (rainfall), Bhuvan/DEM (slope), and soil sensors —
    here it accepts the inputs directly so it can be tested standalone.
    """
    with get_session() as session:
        zone = session.query(models.Zone).filter(models.Zone.id == zone_id).first()
        if not zone:
            raise HTTPException(status_code=404, detail="Zone not found")

        zone.rainfall_mm_24h = inputs.rainfall_mm_24h
        zone.slope_degrees = inputs.slope_degrees
        zone.soil_moisture_pct = inputs.soil_moisture_pct

        score, level = compute_risk_score(
            rainfall_mm_24h=inputs.rainfall_mm_24h,
            slope_degrees=inputs.slope_degrees,
            soil_moisture_pct=inputs.soil_moisture_pct,
            recent_ground_reports=session.query(models.GroundReport)
            .filter(models.GroundReport.zone_id == zone_id)
            .count(),
        )
        zone.risk_score = score
        zone.risk_level = level
        session.commit()
        session.refresh(zone)

        dispatch_alert_if_needed(zone)
        return schemas.ZoneOut.model_validate(zone)


@app.post("/zones/{zone_id}/reports", response_model=schemas.GroundReportOut)
def submit_ground_report(zone_id: int, report: schemas.GroundReportIn):
    """
    Crowdsourced ground-truth signal from a resident — e.g. a crack, water
    seepage, or unusual sound. This is the feedback loop that differentiates
    this system from rainfall-only monitoring.
    """
    with get_session() as session:
        zone = session.query(models.Zone).filter(models.Zone.id == zone_id).first()
        if not zone:
            raise HTTPException(status_code=404, detail="Zone not found")

        new_report = models.GroundReport(
            zone_id=zone_id,
            description=report.description,
            severity=report.severity,
            reporter_contact=report.reporter_contact,
        )
        session.add(new_report)
        session.commit()
        session.refresh(new_report)

        # A ground report nudges the risk score up slightly and can be folded
        # into the next scheduled refresh — see risk_model.compute_risk_score.
        score, level = compute_risk_score(
            rainfall_mm_24h=zone.rainfall_mm_24h,
            slope_degrees=zone.slope_degrees,
            soil_moisture_pct=zone.soil_moisture_pct,
            recent_ground_reports=session.query(models.GroundReport)
            .filter(models.GroundReport.zone_id == zone_id)
            .count(),
        )
        zone.risk_score = score
        zone.risk_level = level
        session.commit()
        dispatch_alert_if_needed(zone)

        # Build the response inside the session block — returning the ORM
        # object directly would detach it once the session closes.
        return schemas.GroundReportOut.model_validate(new_report)


@app.get("/alerts", response_model=list[schemas.AlertOut])
def list_alerts():
    """Alert history, most recent first."""
    with get_session() as session:
        alerts = session.query(models.Alert).order_by(models.Alert.created_at.desc()).limit(50).all()
        return alerts
