"""
Alert dispatch — stubbed for the hackathon demo.

Wire these up before your final demo if you want live SMS:
  - Twilio: pip install twilio, then use Client(...).messages.create(...)
  - Firebase Cloud Messaging: pip install firebase-admin, then messaging.send(...)

Both are commented out below so the app runs with zero external credentials
during development. Swap in real calls and store credentials as environment
variables (never commit them).
"""

import os
from app.database import get_session
from app import models

ALERT_THRESHOLD_LEVELS = {"high", "critical"}

# Uncomment and configure to send real SMS via Twilio:
# from twilio.rest import Client
# twilio_client = Client(os.environ["TWILIO_SID"], os.environ["TWILIO_AUTH_TOKEN"])


def dispatch_alert_if_needed(zone) -> None:
    """Called after any risk score update. Logs + records an alert if the
    zone has crossed into high/critical risk."""
    if zone.risk_level not in ALERT_THRESHOLD_LEVELS:
        return

    message = (
        f"Landslide risk {zone.risk_level.upper()} in {zone.name}, {zone.village}. "
        f"Risk score {zone.risk_score}/100. Avoid the area and follow local guidance."
    )

    with get_session() as session:
        for channel in ("sms", "push", "dashboard"):
            alert = models.Alert(
                zone_id=zone.id,
                zone_name=zone.name,
                risk_level=zone.risk_level,
                message=message,
                channel=channel,
            )
            session.add(alert)
        session.commit()

    _send_sms_stub(message)
    _send_push_stub(message)


def _send_sms_stub(message: str) -> None:
    print(f"[SMS STUB] {message}")
    # twilio_client.messages.create(body=message, from_=..., to=...)


def _send_push_stub(message: str) -> None:
    print(f"[PUSH STUB] {message}")
    # messaging.send(messaging.Message(notification=messaging.Notification(...)))
