from app import models
from app.risk_model import compute_risk_score

SEED_ZONES = [
    dict(name="Sohra ridge", village="Sohra", district="East Khasi Hills",
         latitude=25.2504, longitude=91.7219, rainfall_mm_24h=180, slope_degrees=42, soil_moisture_pct=78),
    dict(name="Dima Hasao slope 4", village="Haflong", district="Dima Hasao",
         latitude=25.1667, longitude=93.0167, rainfall_mm_24h=110, slope_degrees=35, soil_moisture_pct=60),
    dict(name="Ziro valley edge", village="Ziro", district="Lower Subansiri",
         latitude=27.5486, longitude=93.8264, rainfall_mm_24h=60, slope_degrees=22, soil_moisture_pct=45),
    dict(name="Aizawl west cut", village="Aizawl", district="Aizawl",
         latitude=23.7271, longitude=92.7176, rainfall_mm_24h=20, slope_degrees=18, soil_moisture_pct=30),
]


def seed_if_empty(session) -> None:
    if session.query(models.Zone).count() > 0:
        return

    for z in SEED_ZONES:
        score, level = compute_risk_score(
            rainfall_mm_24h=z["rainfall_mm_24h"],
            slope_degrees=z["slope_degrees"],
            soil_moisture_pct=z["soil_moisture_pct"],
            recent_ground_reports=0,
        )
        zone = models.Zone(**z, risk_score=score, risk_level=level)
        session.add(zone)

    session.commit()
