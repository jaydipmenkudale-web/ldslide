from contextlib import contextmanager

from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

# SQLite for local dev / hackathon demo. Swap the URL for Postgres (with PostGIS
# if you add real geospatial queries) when deploying:
#   postgresql://user:password@host:5432/landslide_ews
DATABASE_URL = "sqlite:///./landslide_ews.db"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()


@contextmanager
def get_session():
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()
