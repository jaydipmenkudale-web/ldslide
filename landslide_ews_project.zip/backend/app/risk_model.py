"""
Risk scoring logic.

This module is intentionally isolated from the API layer so the scoring
function can be swapped for a trained model (e.g. XGBoost/Random Forest
trained on GSI historical landslide records) without touching main.py.

Today it's a transparent weighted formula — good for a hackathon demo because
it's explainable to judges and doesn't need a training pipeline to run.

To upgrade to a real ML model:
    1. Train a classifier/regressor offline (see /ml/train.py for a starter
       script) on historical GSI landslide records + rainfall/terrain features.
    2. Serialize it (joblib/pickle) and load it once at import time here.
    3. Replace the body of compute_risk_score with model.predict([[...]]).
    Keep the same function signature so main.py doesn't change.
"""

RISK_LEVELS = [
    (85, "critical"),
    (60, "high"),
    (35, "moderate"),
    (0, "low"),
]


def _level_for_score(score: float) -> str:
    for threshold, level in RISK_LEVELS:
        if score >= threshold:
            return level
    return "low"


def compute_risk_score(
    rainfall_mm_24h: float,
    slope_degrees: float,
    soil_moisture_pct: float,
    recent_ground_reports: int = 0,
) -> tuple[float, str]:
    """
    Returns (risk_score 0-100, risk_level).

    Weighting rationale (tune against real GSI data before relying on this):
      - Rainfall is the strongest short-term trigger for NER slides.
      - Steeper slope raises baseline susceptibility regardless of rain.
      - Saturated soil (high moisture) reduces the rain needed to trigger a slide.
      - Ground reports are a direct human signal and are weighted heavily —
        a single credible report from a resident can matter more than any
        one sensor reading.
    """
    rainfall_component = min(rainfall_mm_24h / 200.0, 1.0) * 45   # up to 45 pts
    slope_component = min(slope_degrees / 60.0, 1.0) * 25         # up to 25 pts
    moisture_component = min(soil_moisture_pct / 100.0, 1.0) * 20  # up to 20 pts
    report_component = min(recent_ground_reports, 5) * 2          # up to 10 pts

    score = rainfall_component + slope_component + moisture_component + report_component
    score = round(min(score, 100.0), 1)

    return score, _level_for_score(score)
