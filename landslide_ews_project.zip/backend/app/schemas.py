from datetime import datetime
from pydantic import BaseModel, ConfigDict


class RiskInputs(BaseModel):
    rainfall_mm_24h: float
    slope_degrees: float
    soil_moisture_pct: float


class ZoneOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    village: str
    district: str
    latitude: float
    longitude: float
    risk_score: float
    risk_level: str


class GroundReportIn(BaseModel):
    description: str
    severity: str = "minor"       # minor | moderate | severe
    reporter_contact: str | None = None


class GroundReportOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    zone_id: int
    description: str
    severity: str
    created_at: datetime


class ZoneDetailOut(BaseModel):
    id: int
    name: str
    village: str
    district: str
    risk_score: float
    risk_level: str
    rainfall_mm_24h: float
    slope_degrees: float
    soil_moisture_pct: float
    recent_reports: list[GroundReportOut]


class AlertOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    zone_id: int
    zone_name: str
    risk_level: str
    message: str
    channel: str
    created_at: datetime
