from datetime import datetime

from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey
from sqlalchemy.orm import relationship

from app.database import Base


class Zone(Base):
    __tablename__ = "zones"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    village = Column(String, nullable=False)
    district = Column(String, nullable=False)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)

    rainfall_mm_24h = Column(Float, default=0.0)
    slope_degrees = Column(Float, default=0.0)
    soil_moisture_pct = Column(Float, default=0.0)

    risk_score = Column(Float, default=0.0)     # 0-100
    risk_level = Column(String, default="low")  # low | moderate | high | critical

    ground_reports = relationship("GroundReport", back_populates="zone")


class GroundReport(Base):
    __tablename__ = "ground_reports"

    id = Column(Integer, primary_key=True, index=True)
    zone_id = Column(Integer, ForeignKey("zones.id"), nullable=False)
    description = Column(String, nullable=False)
    severity = Column(String, default="minor")  # minor | moderate | severe
    reporter_contact = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    zone = relationship("Zone", back_populates="ground_reports")


class Alert(Base):
    __tablename__ = "alerts"

    id = Column(Integer, primary_key=True, index=True)
    zone_id = Column(Integer, ForeignKey("zones.id"), nullable=False)
    zone_name = Column(String, nullable=False)
    risk_level = Column(String, nullable=False)
    message = Column(String, nullable=False)
    channel = Column(String, nullable=False)  # sms | push | dashboard
    created_at = Column(DateTime, default=datetime.utcnow)
